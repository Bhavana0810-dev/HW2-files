from typing import AnyStr, List, Optional, Type, Any
from gentopia.tools.basetool import *
import requests
from pydantic import BaseModel, Field
import os


class NewsSearchArgs(BaseModel):
    query: str = Field(..., description="The search query, e.g., 'artificial intelligence'")
    language: str = Field('en', description="The language code for the news articles, e.g., 'en' for English")
    page_size: int = Field(5, description="Number of results to display per page. 5 is preferred")
    page: int = Field(1, description="Page number for pagination. Default is 1.")


class NewsSearch(BaseTool):
    name = "news_search"
    description = (
        "Search for recent news articles based on a query. "
        "Input a search query, return a list of news articles with information such as title, description, url. "
        "You can repeat calling the function to get next results by incrementing the page number."
    )
    args_schema: Optional[Type[BaseModel]] = NewsSearchArgs
    results: List = []

    def _run(self, query: AnyStr, language: AnyStr = 'en', page_size: int = 5, page: int = 1) -> str:
        api_key = os.environ.get('NEWSAPI_API_KEY')
        if not api_key:
            return "Error: NEWSAPI_API_KEY not set in environment variables."
        url = (
            'https://newsapi.org/v2/everything?'
            f'q={query}&language={language}&pageSize={page_size}&page={page}&apiKey={api_key}'
        )
        response = requests.get(url)
        if response.status_code != 200:
            return f"Error fetching news articles: {response.status_code} - {response.reason}"
        data = response.json()
        if data.get('status') != 'ok':
            return f"Error fetching news articles: {data.get('message', 'Unknown error')}"
        self.results = data.get('articles', [])
        if not self.results:
            return "No further information available."
        ans = []
        for article in self.results:
            ans.append(str({
                'title': article['title'],
                'description': article['description'],
                'url': article['url'],
                'publishedAt': article['publishedAt'],
                'source': article['source']['name'],
            }))
        return '\n\n'.join(ans)

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError


class TopHeadlinesArgs(BaseModel):
    country: str = Field('us', description="The 2-letter ISO 3166-1 code of the country you want to get headlines for.")
    category: Optional[str] = Field(None, description=(
        "The category you want to get headlines for. Options are: business, entertainment, general, health, "
        "science, sports, technology."
    ))
    page_size: int = Field(5, description="Number of results to display per page. 5 is preferred")
    page: int = Field(1, description="Page number for pagination. Default is 1.")


class TopHeadlines(BaseTool):
    name = "top_headlines"
    description = (
        "Get top headlines from news sources. "
        "Input country code and optional category, return a list of news articles. "
        "You can repeat calling the function to get next results by incrementing the page number."
    )
    args_schema: Optional[Type[BaseModel]] = TopHeadlinesArgs
    results: List = []

    def _run(self, country: AnyStr = 'us', category: AnyStr = None, page_size: int = 5, page: int = 1) -> str:
        api_key = os.environ.get('NEWSAPI_API_KEY')
        if not api_key:
            return "Error: NEWSAPI_API_KEY not set in environment variables."
        url = (
            'https://newsapi.org/v2/top-headlines?'
            f'country={country}&pageSize={page_size}&page={page}&apiKey={api_key}'
        )
        if category:
            url += f'&category={category}'
        response = requests.get(url)
        if response.status_code != 200:
            return f"Error fetching top headlines: {response.status_code} - {response.reason}"
        data = response.json()
        if data.get('status') != 'ok':
            return f"Error fetching top headlines: {data.get('message', 'Unknown error')}"
        self.results = data.get('articles', [])
        if not self.results:
            return "No further information available."
        ans = []
        for article in self.results:
            ans.append(str({
                'title': article['title'],
                'description': article['description'],
                'url': article['url'],
                'publishedAt': article['publishedAt'],
                'source': article['source']['name'],
            }))
        return '\n\n'.join(ans)

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError


class NewsSourcesArgs(BaseModel):
    language: str = Field('en', description="The 2-letter ISO-639-1 code of the language you want to get sources for.")
    country: Optional[str] = Field(None, description=(
        "The 2-letter ISO 3166-1 code of the country you want to get sources for."
    ))


class NewsSources(BaseTool):
    name = "news_sources"
    description = (
        "Get a list of news sources. "
        "Input language code and optional country code, return a list of news sources."
    )
    args_schema: Optional[Type[BaseModel]] = NewsSourcesArgs
    results: List = []

    def _run(self, language: AnyStr = 'en', country: AnyStr = None) -> str:
        api_key = os.environ.get('NEWSAPI_API_KEY')
        if not api_key:
            return "Error: NEWSAPI_API_KEY not set in environment variables."
        url = f'https://newsapi.org/v2/sources?language={language}&apiKey={api_key}'
        if country:
            url += f'&country={country}'
        response = requests.get(url)
        if response.status_code != 200:
            return f"Error fetching news sources: {response.status_code} - {response.reason}"
        data = response.json()
        if data.get('status') != 'ok':
            return f"Error fetching news sources: {data.get('message', 'Unknown error')}"
        self.results = data.get('sources', [])
        if not self.results:
            return "No further information available."
        ans = []
        for source in self.results:
            ans.append(str({
                'id': source['id'],
                'name': source['name'],
                'description': source['description'],
                'url': source['url'],
                'category': source['category'],
                'language': source['language'],
                'country': source['country'],
            }))
        return '\n\n'.join(ans)

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError


if __name__ == "__main__":
    # Test NewsSearch
    news_searcher = NewsSearch()
    ans = news_searcher._run("artificial intelligence")
    print("NewsSearch Results:")
    print(ans)

    # Test TopHeadlines
    top_headlines = TopHeadlines()
    ans = top_headlines._run(country='us', category='technology')
    print("\nTopHeadlines Results:")
    print(ans)

    # Test NewsSources
    news_sources = NewsSources()
    ans = news_sources._run(language='en', country='us')
    print("\nNewsSources Results:")
    print(ans)
